package com.mc.job.core.biz;

import com.mc.job.core.biz.model.HandleCallbackParam;
import com.mc.job.core.biz.model.RegistryParam;
import com.mc.job.core.biz.model.ReturnT;

import java.util.List;

/**
 * [AdminBiz 说明/描述]
 *
 * @author likai
 * @version 1.0
 * @date 2019/12/17 0017 16:43
 * @company Gainet
 * @copyright copyright (c) 2019
 */
public interface AdminBiz {

    public static final String MAPPING = "/api";


    // ---------------------- callback ----------------------

    /**
     * callback
     *
     * @param callbackParamList
     * @return
     */
    public ReturnT<String> callback(List<HandleCallbackParam> callbackParamList);


    // ---------------------- registry ----------------------

    /**
     * registry
     *
     * @param registryParam
     * @return
     */
    public ReturnT<String> registry(RegistryParam registryParam);

    /**
     * registry remove
     *
     * @param registryParam
     * @return
     */
    public ReturnT<String> registryRemove(RegistryParam registryParam);
}
