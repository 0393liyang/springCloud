package com.mc.job.core.handler.annotation;

import java.lang.annotation.*;

/**
 * [JobHandler]
 * <pre>
 *     annotation for job handler
 * </pre>
 *
 * @author likai
 * @version 1.0
 * @date 2019/12/17 0017 16:59
 * @company Gainet
 * @copyright copyright (c) 2019
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface JobHandler {

    String value() default "";
}
