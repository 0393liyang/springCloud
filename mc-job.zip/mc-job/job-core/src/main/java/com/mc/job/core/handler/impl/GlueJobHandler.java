package com.mc.job.core.handler.impl;

import com.mc.job.core.biz.model.ReturnT;
import com.mc.job.core.handler.IJobHandler;
import com.mc.job.core.log.JobLogger;

/**
 * [GlueJobHandler 说明/描述]
 *
 * @author likai
 * @version 1.0
 * @date 2019/12/17 0017 16:48
 * @company Gainet
 * @copyright copyright (c) 2019
 */
public class GlueJobHandler extends IJobHandler {

    private long glueUpdatetime;
    private IJobHandler jobHandler;
    public GlueJobHandler(IJobHandler jobHandler, long glueUpdatetime) {
        this.jobHandler = jobHandler;
        this.glueUpdatetime = glueUpdatetime;
    }
    public long getGlueUpdatetime() {
        return glueUpdatetime;
    }

    @Override
    public ReturnT<String> execute(String param) throws Exception {
        JobLogger.log("----------- glue.version:"+ glueUpdatetime +" -----------");
        return jobHandler.execute(param);
    }
}
