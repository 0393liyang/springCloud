package com.mc.job.core.biz;

import com.mc.job.core.biz.model.LogResult;
import com.mc.job.core.biz.model.ReturnT;
import com.mc.job.core.biz.model.TriggerParam;

/**
 * [ExecutorBiz 说明/描述]
 *
 * @author likai
 * @version 1.0
 * @date 2019/12/17 0017 16:43
 * @company Gainet
 * @copyright copyright (c) 2019
 */
public interface ExecutorBiz {

    /**
     * beat
     * @return
     */
    public ReturnT<String> beat();

    /**
     * idle beat
     *
     * @param jobId
     * @return
     */
    public ReturnT<String> idleBeat(int jobId);

    /**
     * kill
     * @param jobId
     * @return
     */
    public ReturnT<String> kill(int jobId);

    /**
     * log
     * @param logDateTim
     * @param logId
     * @param fromLineNum
     * @return
     */
    public ReturnT<LogResult> log(long logDateTim, int logId, int fromLineNum);

    /**
     * run
     * @param triggerParam
     * @return
     */
    public ReturnT<String> run(TriggerParam triggerParam);
}
