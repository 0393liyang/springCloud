package com.mc.job.core.enums;

/**
 * [RegistryConfig 说明/描述]
 *
 * @author likai
 * @version 1.0
 * @date 2019/12/17 0017 16:57
 * @company Gainet
 * @copyright copyright (c) 2019
 */
public class RegistryConfig {

    public static final int BEAT_TIMEOUT = 30;
    public static final int DEAD_TIMEOUT = BEAT_TIMEOUT * 3;

    public enum RegistType{ EXECUTOR, ADMIN }
}
