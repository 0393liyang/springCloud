package com.mc.job.admin.controller.interceptor;

import com.mc.job.admin.core.utils.FtlUtil;
import com.mc.job.admin.core.utils.I18nUtil;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * [CookieInterceptor]
 * <pre>
 *      push cookies to model as cookieMap
 * </pre>
 *
 * @author likai
 * @version 1.0
 * @date 2019/12/17 0017 17:14
 * @company Gainet
 * @copyright copyright (c) 2019
 */
@Component
public class CookieInterceptor extends HandlerInterceptorAdapter {

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                           ModelAndView modelAndView) throws Exception {

        // cookie
        if (modelAndView!=null && ArrayUtils.isNotEmpty(request.getCookies())) {
            HashMap<String, Cookie> cookieMap = new HashMap<String, Cookie>();
            for (Cookie ck : request.getCookies()) {
                cookieMap.put(ck.getName(), ck);
            }
            modelAndView.addObject("cookieMap", cookieMap);
        }

        // static method
        if (modelAndView != null) {
            modelAndView.addObject("I18nUtil", FtlUtil.generateStaticModel(I18nUtil.class.getName()));
        }

        super.postHandle(request, response, handler, modelAndView);
    }

}
