package com.mc.job.admin.dao;

import com.mc.job.admin.core.model.JobGroup;
import org.jboss.logging.Param;

import java.util.List;

/**
 * [JobGroupDao 说明/描述]
 *
 * @author likai
 * @version 1.0
 * @date 2019/12/17 0017 17:21
 * @company Gainet
 * @copyright copyright (c) 2019
 */
@Mapper
public interface JobGroupDao {

    public List<JobGroup> findAll();

    public List<JobGroup> findByAddressType(@Param("addressType") int addressType);

    public int save(JobGroup xxlJobGroup);

    public int update(JobGroup xxlJobGroup);

    public int remove(@Param("id") int id);

    public JobGroup load(@Param("id") int id);
}
