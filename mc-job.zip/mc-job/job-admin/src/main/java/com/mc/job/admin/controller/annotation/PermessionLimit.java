package com.mc.job.admin.controller.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * [PermessionLimit 权限限制]
 *
 * @author likai
 * @version 1.0
 * @date 2019/12/17 0017 17:13
 * @company Gainet
 * @copyright copyright (c) 2019
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface PermessionLimit {

    /**
     * 登录拦截 (默认拦截)
     */
    boolean limit() default true;
}
